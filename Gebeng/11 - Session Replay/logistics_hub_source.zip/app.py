"""
Gebeng Product Warehouse & Dispatch Center
===========================================
Single Flask service -> 5 web exploitation challenges.

Handles dispatch receipts, carrier webhook testing, driver manifest API,
session management, and warehouse safety drills.
"""

import os, time, json, base64, pickle, hashlib, random, re, secrets, uuid
from functools import wraps
from flask import Flask, request, jsonify, make_response, render_template_string, redirect
import jwt as pyjwt                    # PyJWT
import requests as http_requests       # outbound HTTP for SSRF

# ---------------------------------------------------------------------------
# Flags (env-overridable, defaults for local testing)
# ---------------------------------------------------------------------------
FLAG_SSTI   = os.environ.get("FLAG_SSTI",   "PETRONAS{REDACTED}")
FLAG_SSRF   = os.environ.get("FLAG_SSRF",   "PETRONAS{REDACTED}")
FLAG_JWT    = os.environ.get("FLAG_JWT",     "PETRONAS{REDACTED}")
FLAG_PICKLE = os.environ.get("FLAG_PICKLE",  "PETRONAS{REDACTED}")
FLAG_DRILL  = os.environ.get("FLAG_DRILL",   "PETRONAS{REDACTED}")

with open("flag_pickle.txt", "w") as f:
    f.write(FLAG_PICKLE + "\n")

app = Flask(__name__)
app.config["SECRET_KEY"] = os.urandom(32).hex()
app.config["FLAG_SSTI"] = FLAG_SSTI

# ---------------------------------------------------------------------------
# JWT config
# ---------------------------------------------------------------------------
JWT_SECRET = "gebeng2026"              # Weak key — brutable / guessable

# ---------------------------------------------------------------------------
# Branding constants
# ---------------------------------------------------------------------------
LOGO_URI = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 40 40'%3E%3Crect width='40' height='40' rx='6' fill='%23006B3F'/%3E%3Ctext x='20' y='28' font-size='22' text-anchor='middle' fill='white' font-family='Arial,sans-serif' font-weight='bold'%3EG%3C/text%3E%3C/svg%3E"

PETRONAS_GREEN = "#006B3F"
PETRONAS_TEAL  = "#00A19B"

# ===================================================================
#  SHARED HTML LAYOUT
# ===================================================================
LAYOUT_HEAD = f"""<!DOCTYPE html>
<html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Gebeng Dispatch Center — PETRONAS Chemicals</title>
<style>
*{{margin:0;padding:0;box-sizing:border-box}}
body{{font-family:'Segoe UI',system-ui,sans-serif;background:#f4f6f8;color:#1a1a1a}}
.topbar{{background:{PETRONAS_GREEN};color:#fff;padding:12px 24px;display:flex;align-items:center;gap:12px;font-size:0.85rem}}
.topbar img{{width:32px;height:32px;border-radius:6px}}
.topbar .title{{font-weight:700;font-size:1rem;letter-spacing:0.3px}}
.topbar .subtitle{{opacity:0.8;font-size:0.75rem}}
nav{{background:#004d2e;padding:0 24px;display:flex;gap:0}}
nav a{{color:#c8e6c9;padding:10px 18px;text-decoration:none;font-size:0.8rem;letter-spacing:0.3px;border-bottom:2px solid transparent;transition:all 0.15s}}
nav a:hover,nav a.active{{color:#fff;background:rgba(255,255,255,0.08);border-bottom-color:{PETRONAS_TEAL}}}
.container{{max-width:960px;margin:24px auto;padding:0 24px}}
.card{{background:#fff;border-radius:8px;box-shadow:0 1px 3px rgba(0,0,0,0.06);padding:24px;margin-bottom:20px}}
.card h2{{color:{PETRONAS_GREEN};font-size:1.1rem;margin-bottom:12px}}
.btn{{background:{PETRONAS_GREEN};color:#fff;border:none;padding:8px 20px;border-radius:4px;cursor:pointer;font-size:0.85rem}}
.btn:hover{{background:#005a34}}
input[type=text],input[type=number],textarea,select{{width:100%;padding:8px 12px;border:1px solid #ccc;border-radius:4px;font-size:0.85rem;margin-bottom:10px}}
label{{display:block;font-size:0.8rem;color:#555;margin-bottom:4px;font-weight:600}}
table{{width:100%;border-collapse:collapse;font-size:0.82rem}}
th{{background:#f0f0f0;text-align:left;padding:8px 12px;font-weight:600;color:#333}}
td{{padding:8px 12px;border-bottom:1px solid #eee}}
.badge{{display:inline-block;padding:2px 8px;border-radius:10px;font-size:0.7rem;font-weight:600}}
.badge-green{{background:#e8f5e9;color:#2e7d32}}
.badge-yellow{{background:#fff8e1;color:#f57f17}}
.badge-red{{background:#fce4ec;color:#c62828}}
.footer{{text-align:center;padding:20px;color:#999;font-size:0.72rem;margin-top:40px}}
pre{{background:#1a1a1a;color:#a5d6a7;padding:16px;border-radius:6px;font-size:0.78rem;overflow-x:auto;white-space:pre-wrap}}
code{{background:#e8e8e8;padding:2px 6px;border-radius:3px;font-size:0.82rem}}
.mono{{font-family:'Cascadia Code','Fira Code',monospace}}
</style></head><body>
<div class="topbar">
  <img src="{LOGO_URI}" alt="Gebeng">
  <div><div class="title">PETRONAS Chemicals Gebeng</div>
  <div class="subtitle">Product Warehouse &amp; Dispatch Center</div></div>
  <div style="flex:1"></div>
  <span class="badge badge-green">Environment: Production</span>
</div>
<nav>
  <a href="/">Dashboard</a>
  <a href="/dispatch/receipt">Dispatch</a>
  <a href="/carriers/webhook">Carriers</a>
  <a href="/api/docs">API</a>
  <a href="/training/drill">Safety Drill</a>
  <a href="/inventory">Inventory</a>
</nav>
<div class="container">
"""

LAYOUT_FOOT = """
</div>
<div class="footer">
  &copy; 2026 PETRONAS Chemicals Group Berhad &mdash; Gebeng Petrochemical Complex, Kuantan, Pahang<br>
  Dispatch Center v3.4.1 &bull; Internal Use Only
</div>
</body></html>
"""

# ===================================================================
#  HOMEPAGE / DASHBOARD
# ===================================================================
DASHBOARD_HTML = LAYOUT_HEAD + """
<div class="card">
  <h2>Dispatch Dashboard</h2>
  <p style="font-size:0.85rem;color:#555;margin-bottom:16px">
    Real-time overview of product dispatch operations at Gebeng Warehouse Complex.
    The facility handles approximately 2.8 million tonnes of petrochemical products annually
    including MTBE, propylene, acetic acid, and polyethylene pellets.
  </p>
  <table>
    <tr><th>Metric</th><th>Today</th><th>MTD</th></tr>
    <tr><td>Containers Dispatched</td><td>47</td><td>1,284</td></tr>
    <tr><td>Tanker Trucks Processed</td><td>23</td><td>612</td></tr>
    <tr><td>Average Turnaround (hrs)</td><td>2.4</td><td>2.7</td></tr>
    <tr><td>Pending BOL</td><td>8</td><td>—</td></tr>
    <tr><td>Weight Bridge Queue</td><td>3</td><td>—</td></tr>
  </table>
</div>
<div class="card">
  <h2>Active Carriers</h2>
  <table>
    <tr><th>Carrier</th><th>Type</th><th>Active Loads</th><th>Status</th></tr>
    <tr><td>MISC Berhad</td><td>Maritime / ISO Tank</td><td>12</td><td><span class="badge badge-green">Connected</span></td></tr>
    <tr><td>Dialog Group</td><td>Pipeline / Tank Farm</td><td>5</td><td><span class="badge badge-green">Connected</span></td></tr>
    <tr><td>Vopak Terminals</td><td>Terminal Storage</td><td>8</td><td><span class="badge badge-green">Connected</span></td></tr>
    <tr><td>Century Logistics</td><td>Road Tanker</td><td>18</td><td><span class="badge badge-yellow">Webhook Pending</span></td></tr>
    <tr><td>Integrated Logistics (ILB)</td><td>Container</td><td>4</td><td><span class="badge badge-green">Connected</span></td></tr>
  </table>
</div>
""" + LAYOUT_FOOT

# ===================================================================
#  Dispatch Receipt Generator
# ===================================================================
RECEIPT_FORM_HTML = LAYOUT_HEAD + """
<div class="card">
  <h2>Generate Bill of Lading</h2>
  <p style="font-size:0.82rem;color:#555;margin-bottom:16px">
    Create a dispatch receipt for outbound product shipments. Fill in all fields
    and click Generate. The receipt will display below for printing.
  </p>
  <form method="POST" action="/dispatch/receipt">
    <label>Product Name</label>
    <input type="text" name="product_name" placeholder="e.g. MTBE (Methyl tert-butyl ether)" required>
    <label>Container / Tanker ID</label>
    <input type="text" name="container_id" placeholder="e.g. GEB-ISO-2026-0447" required>
    <label>Quantity (MT)</label>
    <input type="number" name="quantity_mt" placeholder="e.g. 24" step="0.1" required>
    <label>Destination</label>
    <input type="text" name="destination" placeholder="e.g. Kuantan Port, Berth 7" required>
    <label>Carrier</label>
    <select name="carrier">
      <option>MISC Berhad</option>
      <option>Dialog Group</option>
      <option>Vopak Terminals</option>
      <option>Century Logistics</option>
      <option>Integrated Logistics (ILB)</option>
    </select>
    <br><button class="btn" type="submit">Generate Receipt</button>
  </form>
</div>
""" + LAYOUT_FOOT


@app.route("/dispatch/receipt", methods=["GET", "POST"])
def dispatch_receipt():
    if request.method == "GET":
        return RECEIPT_FORM_HTML

    product     = request.form.get("product_name", "Unknown Product")
    container   = request.form.get("container_id", "N/A")
    qty         = request.form.get("quantity_mt", "0")
    destination = request.form.get("destination", "N/A")
    carrier     = request.form.get("carrier", "N/A")
    bol_number  = f"GEB-BOL-{random.randint(100000, 999999)}"
    timestamp   = time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime())

    receipt_template = f"""{LAYOUT_HEAD}
<div class="card">
  <h2 style="border-bottom:2px solid {PETRONAS_GREEN};padding-bottom:8px">
    PETRONAS Chemicals Gebeng &mdash; Bill of Lading
  </h2>
  <table style="margin-top:12px">
    <tr><td style="width:160px;font-weight:600;color:#555">BOL Number</td><td class="mono">{bol_number}</td></tr>
    <tr><td style="font-weight:600;color:#555">Date / Time</td><td>{timestamp}</td></tr>
    <tr><td style="font-weight:600;color:#555">Product</td><td>{product}</td></tr>
    <tr><td style="font-weight:600;color:#555">Container ID</td><td class="mono">{container}</td></tr>
    <tr><td style="font-weight:600;color:#555">Quantity</td><td>{qty} MT</td></tr>
    <tr><td style="font-weight:600;color:#555">Destination</td><td>{destination}</td></tr>
    <tr><td style="font-weight:600;color:#555">Carrier</td><td>{carrier}</td></tr>
    <tr><td style="font-weight:600;color:#555">Status</td><td><span class="badge badge-green">Dispatched</span></td></tr>
  </table>
  <p style="margin-top:16px;font-size:0.75rem;color:#999">
    This document is auto-generated by the Gebeng Dispatch Center.
    Verify against the weight bridge log before carrier release.
  </p>
</div>
{LAYOUT_FOOT}"""

    return render_template_string(receipt_template)


# ===================================================================
#  Carrier Webhook Tester
# ===================================================================
WEBHOOK_FORM_HTML = LAYOUT_HEAD + """
<div class="card">
  <h2>Carrier Webhook Tester</h2>
  <p style="font-size:0.82rem;color:#555;margin-bottom:16px">
    Test connectivity to external carrier API endpoints before enabling live webhook integration.
    Enter the carrier's callback URL and the system will perform a server-side GET request to verify reachability.
  </p>
  <form method="GET" action="/carriers/webhook">
    <label>Webhook URL</label>
    <input type="text" name="url" placeholder="https://api.carrier.example.com/webhook/status" required>
    <br><button class="btn" type="submit">Test Connectivity</button>
  </form>
  <div style="margin-top:16px;padding:12px;background:#f9f9f9;border-radius:6px;font-size:0.78rem;color:#666">
    <strong>Configured Carriers:</strong><br>
    &bull; MISC Berhad — <code>https://api.misc.com.my/v2/dispatch</code> (Active)<br>
    &bull; Dialog Group — <code>https://api.dialoggroup.com/logistics/hook</code> (Active)<br>
    &bull; Vopak Terminals — <code>https://vopak-my.api.gateway/callback</code> (Active)<br>
    &bull; Century Logistics — <em>Pending webhook configuration</em>
  </div>
</div>
""" + LAYOUT_FOOT

BLOCKED_HOSTS = [
    "metadata.google.internal",
    "169.254.169.254",
    "metadata.azure.com",
    "100.100.100.200",
]


@app.route("/carriers/webhook")
def carrier_webhook():
    url = request.args.get("url", "")
    if not url:
        return WEBHOOK_FORM_HTML

    from urllib.parse import urlparse
    try:
        parsed = urlparse(url)
    except Exception:
        return jsonify(error="Invalid URL format"), 400

    # ---------------------------------------------------------------
    # Blocklist: cloud metadata endpoints only. 127.0.0.1 NOT blocked.
    # ---------------------------------------------------------------
    if parsed.hostname and any(b in parsed.hostname for b in BLOCKED_HOSTS):
        return jsonify(error="Blocked: cloud metadata endpoint detected", carrier="Webhook test aborted"), 403

    try:
        resp = http_requests.get(url, timeout=5, allow_redirects=False)
        return jsonify(
            status=resp.status_code,
            body=resp.text[:2000],
            content_type=resp.headers.get("Content-Type", "unknown"),
            carrier="Webhook connectivity test complete"
        )
    except http_requests.exceptions.ConnectionError:
        return jsonify(error="Connection refused or host unreachable", carrier="Test failed"), 502
    except http_requests.exceptions.Timeout:
        return jsonify(error="Request timed out (5s limit)", carrier="Test failed"), 504
    except Exception as e:
        return jsonify(error=str(e), carrier="Test failed"), 500


@app.route("/internal/dispatch-key")
def internal_dispatch_key():
    """Internal-only endpoint. Responds only to requests from localhost."""
    if request.remote_addr not in ("127.0.0.1", "::1"):
        return "403 Forbidden — internal dispatch subsystem endpoint", 403
    return FLAG_SSRF


# ===================================================================
#  Driver Manifest API
# ===================================================================
API_DOCS_HTML = LAYOUT_HEAD + """
<div class="card">
  <h2>Dispatch API Documentation</h2>
  <p style="font-size:0.82rem;color:#555;margin-bottom:16px">
    REST API for driver manifest access. Drivers authenticate with JWT tokens.
  </p>
  <table>
    <tr><th>Endpoint</th><th>Method</th><th>Auth</th><th>Description</th></tr>
    <tr><td><code>/api/register</code></td><td>POST</td><td>None</td><td>Register as a driver. Body: <code>{"username":"..."}</code></td></tr>
    <tr><td><code>/api/manifest</code></td><td>GET</td><td>JWT</td><td>View assigned cargo manifest</td></tr>
    <tr><td><code>/api/manifest/restricted</code></td><td>GET</td><td>JWT (supervisor)</td><td>Restricted dispatch records — supervisor access only</td></tr>
  </table>
  <div style="margin-top:16px;padding:12px;background:#fff8e1;border-radius:6px;font-size:0.78rem;color:#795548">
    <strong>Authentication:</strong> Include the token in the <code>Authorization: Bearer &lt;token&gt;</code> header.
    Tokens are signed with HMAC-SHA256.
  </div>
</div>
""" + LAYOUT_FOOT

MANIFEST_DATA = [
    {"id": "GEB-DSP-0891", "product": "MTBE", "quantity": "24 MT", "dest": "Kuantan Port Berth 7", "status": "loaded"},
    {"id": "GEB-DSP-0892", "product": "Propylene", "quantity": "18 MT", "dest": "PIC Johor Pipeline", "status": "pending"},
    {"id": "GEB-DSP-0893", "product": "Acetic Acid", "quantity": "12 MT", "dest": "Kemaman Supply Base", "status": "in-transit"},
    {"id": "GEB-DSP-0894", "product": "Polyethylene HD", "quantity": "32 MT", "dest": "Westport Container Terminal", "status": "loaded"},
]


@app.route("/api/docs")
def api_docs():
    return API_DOCS_HTML


@app.route("/api/register", methods=["POST"])
def api_register():
    data = request.get_json(silent=True) or {}
    username = data.get("username", "")
    if not username or len(username) < 2:
        return jsonify(error="Provide a username (min 2 chars)"), 400

    token = pyjwt.encode(
        {"sub": username, "role": "driver", "iat": int(time.time())},
        JWT_SECRET,
        algorithm="HS256"
    )
    return jsonify(
        ok=True,
        token=token,
        message=f"Driver {username} registered. Use this token in the Authorization header.",
        role="driver"
    )


def _verify_jwt():
    auth = request.headers.get("Authorization", "")
    if not auth.startswith("Bearer "):
        return None, "Missing or malformed Authorization header. Use: Bearer <token>"
    token = auth[7:]
    try:
        header = pyjwt.get_unverified_header(token)
        alg = header.get("alg", "HS256")
        if alg.lower() == "none":
            payload = pyjwt.decode(
                token, options={"verify_signature": False}, algorithms=["none"]
            )
        else:
            payload = pyjwt.decode(token, JWT_SECRET, algorithms=["HS256"])
        return payload, None
    except pyjwt.InvalidTokenError as e:
        return None, f"Invalid token: {e}"


@app.route("/api/manifest")
def api_manifest():
    payload, err = _verify_jwt()
    if err:
        return jsonify(error=err), 401
    return jsonify(
        ok=True,
        driver=payload.get("sub"),
        role=payload.get("role"),
        manifests=MANIFEST_DATA
    )


@app.route("/api/manifest/restricted")
def api_manifest_restricted():
    payload, err = _verify_jwt()
    if err:
        return jsonify(error=err), 401
    if payload.get("role") != "supervisor":
        return jsonify(
            error="Access denied. This endpoint requires supervisor privileges.",
            your_role=payload.get("role"),
            required_role="supervisor"
        ), 403

    return jsonify(
        ok=True,
        classification="RESTRICTED — Gebeng Dispatch Supervisor Only",
        manifests=MANIFEST_DATA + [
            {"id": "GEB-DSP-CLASSIFIED", "product": "Supervisor Override Record",
             "quantity": "—", "dest": "—", "status": "classified",
             "dispatch_auth_key": FLAG_JWT}
        ]
    )


# ===================================================================
#  Session Management
# ===================================================================
@app.before_request
def load_dispatch_session():
    """Load session from dispatch_session cookie (base64-encoded pickle)."""
    raw = request.cookies.get("dispatch_session", "")
    if raw:
        try:
            request.dispatch_session = pickle.loads(base64.b64decode(raw))
        except Exception:
            request.dispatch_session = {"role": "guest", "warehouse": "A", "shift": "day"}
    else:
        request.dispatch_session = {"role": "guest", "warehouse": "A", "shift": "day"}


@app.after_request
def set_dispatch_session(response):
    """Serialize session back to cookie (only if no custom session was set)."""
    if hasattr(request, "dispatch_session") and isinstance(request.dispatch_session, dict):
        encoded = base64.b64encode(pickle.dumps(request.dispatch_session)).decode()
        response.set_cookie("dispatch_session", encoded, httponly=True, samesite="Lax")
    return response


@app.route("/session/info")
def session_info():
    """Debug endpoint — shows current session data (for players to discover the cookie format)."""
    s = getattr(request, "dispatch_session", {})
    if isinstance(s, dict):
        session_repr = s
    else:
        session_repr = {"note": "Session object is not a dict", "type": str(type(s)),
                        "value": str(s)[:500]}
    return jsonify(
        session=session_repr,
        cookie_format="base64(pickle.dumps(session_dict))",
        hint="The dispatch_session cookie controls your access level"
    )


# ===================================================================
#  Safety Drill — Warehouse Training
# ===================================================================
DRILL_SENTENCES = [
    "All forklift operators at the Gebeng warehouse must wear high-visibility vests and steel-toed boots during loading operations.",
    "Chemical product containers must be stored in designated bunded areas with secondary containment capacity of at least one hundred and ten percent.",
    "MTBE containers must be stored in ventilated areas away from ignition sources with maximum stack height of three units per bay.",
    "Tanker drivers must complete the daily vehicle inspection checklist before entering the dispatch zone.",
    "Emergency spill containment kits are located at every loading bay entrance and must be inspected weekly by the HSE coordinator.",
    "The weight bridge operator shall verify the tare weight and gross weight of every outbound tanker before issuing the dispatch note.",
    "Polyethylene pellet bags must be covered with weatherproof tarpaulin during open-yard staging to prevent moisture contamination.",
    "Propylene cylinders require special handling permits and must be transported in approved cradle frames with chain restraints.",
    "All warehouse personnel must attend the monthly fire drill conducted by the Gebeng Emergency Response Team on the first Tuesday.",
    "Loading bay doors must remain closed when not in active use to maintain positive pressure ventilation inside the warehouse.",
    "ISO tank containers require a pre-dispatch pressure test and visual inspection of the valve assembly before release to the carrier.",
    "The dispatch coordinator must verify the Material Safety Data Sheet matches the product label on every outbound container.",
    "Acetic acid shipments require corrosion-resistant placarding and must not be staged adjacent to alkaline product bays.",
    "Tanker drivers entering the Gebeng dispatch zone must present their CIDB safety card and complete registration at the gatehouse.",
    "Warehouse supervisors must conduct a shift handover briefing covering pending dispatches and any active safety advisories.",
    "The Gebeng product warehouse handles an average of forty-seven container dispatches per day across five active loading bays.",
    "Emergency shutdown procedures for the loading arm system require simultaneous activation of both the local and remote isolation valves.",
    "All outbound shipments of hazardous materials must be accompanied by a completed UN transport document and emergency contact card.",
    "Quarterly equipment calibration records for the weight bridge and gas detection systems must be filed with the QC laboratory.",
    "Officers must verify that all communication channels are operational before authorizing vessel departure from the chemical terminal.",
]

DRILL_SESSIONS = {}     # session_id -> { level, started_at, sentence_order }
TOTAL_LEVELS   = 20
BASE_WPM       = 30
WPM_INCREMENT  = 5      # 30, 35, 40, ... 125

DRILL_UI_HTML = LAYOUT_HEAD + """
<div class="card">
  <h2>Warehouse Safety Drill</h2>
  <p style="font-size:0.82rem;color:#555;margin-bottom:12px">
    All warehouse personnel must pass the chemical handling safety drill before receiving forklift operator certification.
    Type the displayed safety procedure accurately and quickly. Speed requirement increases with each level.
  </p>
  <div id="game" style="display:none">
    <div style="display:flex;gap:16px;align-items:center;margin-bottom:12px">
      <span style="font-size:0.78rem;color:#555">Level <strong id="level">1</strong>/<span id="total">20</span></span>
      <span style="font-size:0.78rem;color:#555">Required: <strong id="required">30</strong> WPM</span>
      <div style="flex:1;height:6px;background:#e0e0e0;border-radius:3px;overflow:hidden">
        <div id="progress-bar" style="height:100%;background:""" + PETRONAS_TEAL + """;width:0%;transition:width 0.3s"></div>
      </div>
    </div>
    <p id="target" style="font-family:'Cascadia Code','Fira Code',monospace;font-size:0.88rem;line-height:1.7;background:#fafafa;padding:16px;border-radius:6px;border:1px solid #e0e0e0;margin-bottom:12px;min-height:60px"></p>
    <textarea id="input" rows="3" placeholder="Start typing the sentence above..." style="font-family:'Cascadia Code',monospace;font-size:0.88rem" disabled></textarea>
    <p id="verdict" style="font-size:0.82rem;margin-top:8px;min-height:20px"></p>
  </div>
  <div id="done" style="display:none;text-align:center;padding:32px 0">
    <h3 style="color:""" + PETRONAS_GREEN + """">&#10003; Safety Drill Complete</h3>
    <p style="margin:12px 0;font-size:0.85rem">All levels cleared. Forklift operator certification approved.</p>
    <pre id="flag" style="font-size:1.1rem;display:inline-block;padding:12px 24px"></pre><br>
    <button id="copy-btn" class="btn" style="margin-top:12px">Copy Flag</button>
  </div>
  <button id="reset-btn" class="btn" style="background:#666;margin-top:12px">Reset Drill</button>
</div>
<script>
const el=id=>document.getElementById(id);
const api=async(path,opts)=>{const r=await fetch(path,{method:opts?.method||"GET",headers:{"Content-Type":"application/json"},body:opts?.body?JSON.stringify(opts.body):undefined,credentials:"include"});return r.json()};
let currentSentence="";

function renderSentence(text){const t=el("target");t.innerHTML="";for(const ch of text){const s=document.createElement("span");s.textContent=ch;s.style.color="#bbb";t.appendChild(s)}}
function updateHighlight(){const typed=el("input").value,spans=el("target").children;for(let i=0;i<currentSentence.length;i++){if(i>=typed.length)spans[i].style.color="#bbb";else spans[i].style.color=typed[i]===currentSentence[i]?"#2e7d32":"#c62828"}}
function setVerdict(msg,good){const v=el("verdict");v.textContent=msg||"";v.style.color=good?"#2e7d32":"#c62828"}

async function beginAttempt(){await api("/training/api/start",{method:"POST"});el("input").value="";el("input").disabled=false;updateHighlight();el("input").focus();setVerdict("")}
async function loadLevel(){const state=await api("/training/api/state");if(state.done){showDone(state.flag);return}el("game").style.display="block";el("done").style.display="none";el("level").textContent=state.level;el("total").textContent=state.total;el("required").textContent=state.required_wpm;el("progress-bar").style.width=((state.level-1)/state.total*100)+"%";currentSentence=state.sentence;renderSentence(currentSentence);await beginAttempt()}
function showDone(flag){el("game").style.display="none";el("done").style.display="block";el("progress-bar").style.width="100%";el("flag").textContent=flag}
async function handleComplete(){el("input").disabled=true;const res=await api("/training/api/submit",{method:"POST",body:{text:el("input").value}});if(res.error){setVerdict(res.error,false);el("input").disabled=false;return}if(!res.ok){setVerdict(res.verdict,false);setTimeout(beginAttempt,1100);return}setVerdict(res.verdict+" ("+res.wpm+" wpm)",true);if(res.done)setTimeout(()=>showDone(res.flag),900);else setTimeout(loadLevel,1000)}
el("input").addEventListener("input",()=>{updateHighlight();if(el("input").value===currentSentence)handleComplete()});
el("copy-btn").addEventListener("click",()=>{navigator.clipboard.writeText(el("flag").textContent);el("copy-btn").textContent="Copied!";setTimeout(()=>el("copy-btn").textContent="Copy Flag",1500)});
el("reset-btn").addEventListener("click",async()=>{await api("/training/api/reset",{method:"POST"});loadLevel()});
loadLevel();
</script>
""" + LAYOUT_FOOT


def _get_drill_session():
    sid = request.cookies.get("drill_session", "")
    if sid and sid in DRILL_SESSIONS:
        return sid, DRILL_SESSIONS[sid]
    sid = secrets.token_hex(16)
    order = list(range(len(DRILL_SENTENCES)))
    random.shuffle(order)
    session = {"level": 1, "started_at": None, "sentence_order": order[:TOTAL_LEVELS]}
    DRILL_SESSIONS[sid] = session
    return sid, session


@app.route("/training/drill")
def training_drill():
    resp = make_response(DRILL_UI_HTML)
    sid, _ = _get_drill_session()
    resp.set_cookie("drill_session", sid, httponly=True, samesite="Lax")
    return resp


@app.route("/training/api/state")
def drill_state():
    sid, session = _get_drill_session()
    level = session["level"]
    if level > TOTAL_LEVELS:
        return jsonify(done=True, flag=FLAG_DRILL)
    idx = session["sentence_order"][level - 1]
    resp = make_response(jsonify(
        level=level,
        total=TOTAL_LEVELS,
        required_wpm=BASE_WPM + (level - 1) * WPM_INCREMENT,
        sentence=DRILL_SENTENCES[idx],
        done=False
    ))
    resp.set_cookie("drill_session", sid, httponly=True, samesite="Lax")
    return resp


@app.route("/training/api/start", methods=["POST"])
def drill_start():
    sid, session = _get_drill_session()
    session["started_at"] = time.time()
    resp = make_response(jsonify(ok=True))
    resp.set_cookie("drill_session", sid, httponly=True, samesite="Lax")
    return resp


@app.route("/training/api/submit", methods=["POST"])
def drill_submit():
    sid, session = _get_drill_session()
    if session["started_at"] is None:
        return jsonify(error="Call /training/api/start before /training/api/submit"), 400
    level = session["level"]
    if level > TOTAL_LEVELS:
        return jsonify(done=True, flag=FLAG_DRILL)

    data = request.get_json(silent=True) or {}
    text = data.get("text", "")
    idx = session["sentence_order"][level - 1]
    expected = DRILL_SENTENCES[idx]

    if text != expected:
        session["started_at"] = None
        resp = make_response(jsonify(ok=False, verdict="Text mismatch. Try again."))
        resp.set_cookie("drill_session", sid, httponly=True, samesite="Lax")
        return resp

    elapsed = time.time() - session["started_at"]
    if elapsed < 0.5:
        elapsed = 0.5
    words = len(expected.split())
    wpm = round(words / (elapsed / 60), 1)
    required = BASE_WPM + (level - 1) * WPM_INCREMENT

    if wpm < required:
        session["started_at"] = None
        resp = make_response(jsonify(ok=False, verdict=f"Too slow: {wpm} WPM (need {required})", wpm=wpm))
        resp.set_cookie("drill_session", sid, httponly=True, samesite="Lax")
        return resp

    session["level"] = level + 1
    session["started_at"] = None
    done = session["level"] > TOTAL_LEVELS
    result = {"ok": True, "wpm": wpm, "verdict": "Level cleared!", "done": done}
    if done:
        result["flag"] = FLAG_DRILL
    resp = make_response(jsonify(result))
    resp.set_cookie("drill_session", sid, httponly=True, samesite="Lax")
    return resp


@app.route("/training/api/reset", methods=["POST"])
def drill_reset():
    sid = request.cookies.get("drill_session", "")
    if sid in DRILL_SESSIONS:
        del DRILL_SESSIONS[sid]
    sid, session = _get_drill_session()
    resp = make_response(jsonify(ok=True, message="Drill reset to level 1"))
    resp.set_cookie("drill_session", sid, httponly=True, samesite="Lax")
    return resp


# ===================================================================
#  DECOY / REALISTIC ENDPOINTS (no vulns — red herrings)
# ===================================================================
INVENTORY_DATA = [
    {"bay": "A1", "product": "MTBE", "stock_mt": 480, "capacity_mt": 600, "status": "normal"},
    {"bay": "A2", "product": "MTBE", "stock_mt": 210, "capacity_mt": 600, "status": "low"},
    {"bay": "B1", "product": "Propylene", "stock_mt": 340, "capacity_mt": 400, "status": "normal"},
    {"bay": "B2", "product": "Acetic Acid", "stock_mt": 95, "capacity_mt": 200, "status": "low"},
    {"bay": "C1", "product": "Polyethylene HD", "stock_mt": 1200, "capacity_mt": 1500, "status": "normal"},
    {"bay": "C2", "product": "Polyethylene LD", "stock_mt": 870, "capacity_mt": 1000, "status": "normal"},
    {"bay": "D1", "product": "n-Butane", "stock_mt": 60, "capacity_mt": 150, "status": "critical"},
    {"bay": "D2", "product": "Isobutylene", "stock_mt": 180, "capacity_mt": 200, "status": "normal"},
]


@app.route("/inventory")
def inventory():
    html = LAYOUT_HEAD + """<div class="card"><h2>Warehouse Inventory Status</h2><table>
    <tr><th>Bay</th><th>Product</th><th>Stock (MT)</th><th>Capacity (MT)</th><th>%</th><th>Status</th></tr>"""
    for item in INVENTORY_DATA:
        pct = round(item["stock_mt"] / item["capacity_mt"] * 100)
        badge = "badge-green" if item["status"] == "normal" else ("badge-yellow" if item["status"] == "low" else "badge-red")
        html += f'<tr><td>{item["bay"]}</td><td>{item["product"]}</td><td>{item["stock_mt"]}</td>'
        html += f'<td>{item["capacity_mt"]}</td><td>{pct}%</td><td><span class="badge {badge}">{item["status"]}</span></td></tr>'
    html += "</table></div>" + LAYOUT_FOOT
    return html


@app.route("/")
def index():
    return DASHBOARD_HTML


# ===================================================================
#  STARTUP
# ===================================================================
if __name__ == "__main__":
    from werkzeug.debug import DebuggedApplication
    app.wsgi_app = DebuggedApplication(app.wsgi_app, evalex=False)
    app.run("0.0.0.0", port=5000, debug=False, use_reloader=False)
