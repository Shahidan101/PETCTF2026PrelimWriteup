<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| LabTrack LIMS — Routes
|--------------------------------------------------------------------------
|
| Gebeng QC Laboratory Information Management System.
| Manages certificates of analysis, batch uploads, and lab equipment data.
|
*/

// =========================================================================
//  HOME PAGE
// =========================================================================

Route::get('/', function () {
    return view('operations');
});

// =========================================================================
//  Batch Upload — XML Processing
// =========================================================================

Route::post('/safety/upload', function (Request $request) {
    $xml = $request->getContent();

    if (empty($xml)) {
        return response()->json(['error' => 'No XML body provided'], 400);
    }

    $doc = @simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NOENT | LIBXML_NOERROR);

    if ($doc === false) {
        return response()->json(['error' => 'Invalid XML document. Ensure well-formed SDS format.'], 400);
    }

    $name     = (string) ($doc->chemical_name   ?? 'Unknown');
    $cas      = (string) ($doc->cas_number       ?? 'N/A');
    $hazard   = (string) ($doc->hazard_class     ?? 'Not specified');
    $supplier = (string) ($doc->supplier         ?? 'Not specified');

    return response()->json([
        'status'   => 'received',
        'chemical' => $name,
        'cas'      => $cas,
        'hazard'   => $hazard,
        'supplier' => $supplier,
        'message'  => "SDS for {$name} (CAS: {$cas}) has been logged to the HSE registry.",
    ]);
})->withoutMiddleware([\App\Http\Middleware\VerifyCsrfToken::class]);


Route::get('/safety', function () {
    return view('safety');
});


// =========================================================================
//  Certificates of Analysis — Document Retrieval
// =========================================================================

Route::get('/reports', function (Request $request) {
    $file = $request->get('file', '');

    if (!$file) {
        return view('reports-index');
    }

    $basePath = storage_path('reports/');
    $fullPath = $basePath . $file;

    if (!file_exists($fullPath)) {
        return response('Report not found.', 404)
            ->header('Content-Type', 'text/plain');
    }

    $content = file_get_contents($fullPath);
    return response($content, 200)
        ->header('Content-Type', 'text/plain')
        ->header('Content-Disposition', 'inline; filename="' . basename($file) . '"');
});


// =========================================================================
//  Lab Equipment & Calibration
// =========================================================================

Route::get('/facility', function () {
    return view('facility');
});
