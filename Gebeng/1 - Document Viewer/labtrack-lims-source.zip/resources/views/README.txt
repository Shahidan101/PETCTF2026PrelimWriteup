Blade views are standard HTML with PETRONAS Gebeng branding.
Not included in source archive — retrieve from the live application.
