<?php
/*
 * PIC Operations Portal — Application Config (excerpt)
 *
 * NOTE: This is a partial config provided for challenge context.
 *       The full application runs Laravel 8 with standard config.
 */

return [
    'name'     => env('APP_NAME', 'PIC Operations Portal'),
    'env'      => env('APP_ENV', 'local'),
    'debug'    => (bool) env('APP_DEBUG', true),
    'url'      => env('APP_URL', 'http://localhost'),

    'providers' => [
        // ... standard Laravel 8 providers ...
        Illuminate\Foundation\Providers\FoundationServiceProvider::class,
        Illuminate\View\ViewServiceProvider::class,
        Illuminate\Session\SessionServiceProvider::class,
        // ... etc ...
    ],

    /*
     * Package auto-discovery is enabled.
     * Installed packages register their service providers automatically.
     * See composer.json for the full dependency list.
     */
];
