"""
Gebeng Chemical Plant Operations Portal
========================================
PC MTBE Sdn Bhd — Internal OT Portal for plant operations,
equipment management, and process diagnostics.
"""

import os
import re
import sqlite3
import uuid

from flask import Flask, request, jsonify, make_response, render_template_string

# ---------------------------------------------------------------------------
# Flags (env-overridable, defaults for local testing)
# ---------------------------------------------------------------------------
FLAG_SQLI  = os.environ.get("FLAG_SQLI",  "PETRONAS{REDACTED}")
FLAG_LDAP  = os.environ.get("FLAG_LDAP",  "PETRONAS{REDACTED}")
FLAG_EVAL  = os.environ.get("FLAG_EVAL",  "PETRONAS{REDACTED}")

with open("flag.txt", "w") as f:
    f.write(FLAG_EVAL + "\n")

app = Flask(__name__)
app.config["SECRET_KEY"] = os.urandom(32).hex()


# ===================================================================
#  Order Database
# ===================================================================

DB_PATH = "/tmp/gebeng_orders.db"


def _init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("DROP TABLE IF EXISTS order_tracking")
    c.execute("DROP TABLE IF EXISTS chemical_archive")
    c.execute("DROP TABLE IF EXISTS users")
    c.execute("DROP TABLE IF EXISTS shift_schedule")
    c.execute("DROP TABLE IF EXISTS incident_log")
    c.execute("""
        CREATE TABLE order_tracking (
            order_ref TEXT PRIMARY KEY,
            chemical  TEXT NOT NULL,
            quantity  TEXT NOT NULL,
            status    TEXT NOT NULL
        )
    """)
    c.execute("""
        CREATE TABLE users (
            id       INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL,
            password TEXT NOT NULL,
            role     TEXT NOT NULL
        )
    """)
    c.execute("""
        CREATE TABLE chemical_archive (
            id        INTEGER PRIMARY KEY AUTOINCREMENT,
            entry_ref TEXT NOT NULL,
            auth_key  TEXT NOT NULL
        )
    """)
    c.execute("""
        CREATE TABLE shift_schedule (
            id        INTEGER PRIMARY KEY AUTOINCREMENT,
            shift     TEXT NOT NULL,
            team      TEXT NOT NULL,
            date      TEXT NOT NULL
        )
    """)
    c.execute("""
        CREATE TABLE incident_log (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp   TEXT NOT NULL,
            severity    TEXT NOT NULL,
            description TEXT NOT NULL,
            resolved    INTEGER DEFAULT 0
        )
    """)

    c.execute("INSERT INTO order_tracking VALUES ('seed-order-0001', 'Methanol', '850 MT', 'pending')")
    c.execute("INSERT INTO order_tracking VALUES ('GEB-2026-0044', 'Propane', '1200 MT', 'delivered')")
    c.execute("INSERT INTO order_tracking VALUES ('GEB-2026-0045', 'n-Butane', '740 MT', 'in-transit')")
    c.execute("INSERT INTO order_tracking VALUES ('GEB-2026-0046', 'Isobutylene', '320 MT', 'delivered')")
    c.execute("INSERT INTO order_tracking VALUES ('GEB-2026-0047', 'Methanol', '900 MT', 'processing')")
    c.execute("INSERT INTO order_tracking VALUES ('GEB-2026-0048', 'Catalyst Regen Media', '12 MT', 'pending')")

    c.execute("INSERT INTO users VALUES (1, 'chem_admin', 'G3b3ng$up3r2026!', 'admin')")
    c.execute("INSERT INTO users VALUES (2, 'operator', 'shift_op_2026', 'operator')")
    c.execute("INSERT INTO users VALUES (3, 'readonly', 'viewer2026', 'viewer')")

    c.execute("INSERT INTO chemical_archive VALUES (1, 'GEB-AUTH-001', ?)", (FLAG_SQLI,))

    c.execute("INSERT INTO shift_schedule VALUES (1, 'Morning', 'Team Alpha', '2026-11-09')")
    c.execute("INSERT INTO shift_schedule VALUES (2, 'Afternoon', 'Team Bravo', '2026-11-09')")
    c.execute("INSERT INTO shift_schedule VALUES (3, 'Night', 'Team Charlie', '2026-11-09')")

    c.execute("INSERT INTO incident_log VALUES (1, '2026-10-28 14:22', 'LOW', 'GEB-HX02 vibration above baseline', 0)")
    c.execute("INSERT INTO incident_log VALUES (2, '2026-10-15 09:11', 'LOW', 'Cooling tower fan belt wear detected', 1)")
    c.execute("INSERT INTO incident_log VALUES (3, '2026-09-30 16:45', 'MEDIUM', 'GPP Kerteh pipeline pressure drop 2.1%', 1)")

    conn.commit()
    conn.close()


_init_db()


# ===================================================================
#  Plant Asset Registry
# ===================================================================

LDAP_ENTRIES = [
    {"cn": "GEB-R01-Reactor-Primary",      "type": "MTBE Reactor",        "status": "Online"},
    {"cn": "GEB-R02-Reactor-Secondary",     "type": "MTBE Reactor",        "status": "Online"},
    {"cn": "GEB-R03-PDH-Reactor",           "type": "Oleflex Reactor",     "status": "Online"},
    {"cn": "GEB-D01-Distillation-Column",   "type": "Fractionation Unit",  "status": "Online"},
    {"cn": "GEB-D02-Distillation-Column",   "type": "Fractionation Unit",  "status": "Standby"},
    {"cn": "GEB-HX01-Heat-Exchanger",       "type": "Shell-and-Tube",      "status": "Online"},
    {"cn": "GEB-HX02-Heat-Exchanger",       "type": "Plate Type",          "status": "Maintenance"},
    {"cn": "GEB-TK01-Methanol-Storage",     "type": "Storage Tank",        "status": "Online"},
    {"cn": "GEB-TK02-MTBE-Storage",         "type": "Storage Tank",        "status": "Online"},
    {"cn": "GEB-TK03-Isobutylene-Feed",     "type": "Pressurized Tank",    "status": "Online"},
    {"cn": "GEB-TK04-Propane-Buffer",       "type": "Pressurized Tank",    "status": "Online"},
    {"cn": "GEB-PP01-Feed-Pump",            "type": "Centrifugal Pump",    "status": "Online"},
    {"cn": "GEB-PP02-Transfer-Pump",        "type": "Centrifugal Pump",    "status": "Standby"},
    {"cn": "GEB-PP03-Booster-Pump",         "type": "Centrifugal Pump",    "status": "Online"},
    {"cn": "GEB-CT01-Cooling-Tower",        "type": "Induced Draft",       "status": "Online"},
    {"cn": "GEB-FN01-PDH-Furnace",          "type": "Process Furnace",     "status": "Online"},
    {"cn": "GEB-CP01-Compressor",           "type": "Centrifugal",         "status": "Online"},
    {"cn": "GEB-MNT-098-Terminal",          "type": "Maintenance Terminal", "status": "Restricted"},
    {
        "cn": "GEB-MNT-099-Console",
        "type": "Maintenance Terminal",
        "status": "Restricted",
        "maintenanceKey": FLAG_LDAP,
    },
]


class LDAPFilterError(Exception):
    pass


class LDAPAttributeError(Exception):
    pass


def _parse_filter(expr: str, pos: int = 0):
    if pos >= len(expr):
        raise LDAPFilterError("Unexpected end of filter")
    if expr[pos] != "(":
        raise LDAPFilterError(f"Expected '(' at position {pos}")
    pos += 1

    if expr[pos] in ("&", "|"):
        op = expr[pos]
        pos += 1
        components = []
        while pos < len(expr) and expr[pos] == "(":
            comp, pos = _parse_filter(expr, pos)
            components.append(comp)
        if pos >= len(expr) or expr[pos] != ")":
            raise LDAPFilterError("Missing closing ')' for composite filter")
        pos += 1
        return {"op": op, "components": components}, pos

    if expr[pos] == "!":
        pos += 1
        comp, pos = _parse_filter(expr, pos)
        if pos >= len(expr) or expr[pos] != ")":
            raise LDAPFilterError("Missing closing ')' for NOT filter")
        pos += 1
        return {"op": "!", "component": comp}, pos

    end = expr.find(")", pos)
    if end == -1:
        raise LDAPFilterError("Missing closing ')'")
    simple = expr[pos:end]
    pos = end + 1

    eq_idx = simple.find("=")
    if eq_idx == -1:
        raise LDAPFilterError(f"Invalid simple filter: {simple}")

    attr = simple[:eq_idx].strip()
    value = simple[eq_idx + 1:]

    known_attrs = {"cn", "type", "status", "maintenanceKey"}
    if attr not in known_attrs:
        raise LDAPAttributeError(f"Unknown attribute: {attr}")

    return {"op": "simple", "attr": attr, "value": value}, pos


def _match_simple(entry, attr, pattern):
    val = entry.get(attr, "")
    if not val:
        return False
    pattern_lower = pattern.lower()
    val_lower = val.lower()
    if pattern_lower == "*":
        return True
    if "*" not in pattern_lower:
        return val_lower == pattern_lower
    parts = pattern_lower.split("*")
    idx = 0
    for i, part in enumerate(parts):
        if not part:
            continue
        found = val_lower.find(part, idx)
        if found == -1:
            return False
        if i == 0 and not pattern_lower.startswith("*") and found != 0:
            return False
        idx = found + len(part)
    if not pattern_lower.endswith("*") and parts[-1]:
        if not val_lower.endswith(parts[-1]):
            return False
    return True


def _evaluate_filter(entry, filt):
    op = filt["op"]
    if op == "simple":
        return _match_simple(entry, filt["attr"], filt["value"])
    if op == "&":
        return all(_evaluate_filter(entry, c) for c in filt["components"])
    if op == "|":
        return any(_evaluate_filter(entry, c) for c in filt["components"])
    if op == "!":
        return not _evaluate_filter(entry, filt["component"])
    return False


def ldap_search(user_input: str):
    raw_filter = f"(cn=*{user_input}*)"
    try:
        parsed, consumed = _parse_filter(raw_filter, 0)
    except LDAPFilterError as e:
        raise e
    except LDAPAttributeError as e:
        raise e

    remaining = raw_filter[consumed:]
    if remaining:
        extra_filters = []
        try:
            while remaining:
                pf, consumed2 = _parse_filter(remaining, 0)
                extra_filters.append(pf)
                remaining = remaining[consumed2:]
        except LDAPFilterError:
            raise LDAPFilterError("Invalid compound filter")
        combined = {"op": "&", "components": [parsed] + extra_filters}
    else:
        combined = parsed

    results = []
    for entry in LDAP_ENTRIES:
        if _evaluate_filter(entry, combined):
            results.append({"cn": entry["cn"], "type": entry["type"], "status": entry["status"]})
    return results


# ===================================================================
#  Diagnostics Engine
# ===================================================================

def check_diagnostic_input(string: str) -> bool:
    string = string.lower()
    disallowed = [
        ".", "_", "import", "=", ",", "'", '"', "attr", "global", "local",
        ";", ":", "^", "/", ">", "<", "{", "}", "m", "a", "not", "and", "or",
        "eval", "exec", "for", "in", "chr", "ord", "hex", "int", "repr",
        "str", "dir", "set", "len", "random", "request", "app", "flask",
        "config", "flag", "secret", "os", "sys", "subprocess", "builtins",
    ]
    c = any(x in string for x in disallowed)
    non_ascii = any(ord(x) < 32 for x in string) or any(ord(x) > 126 for x in string)
    return c or non_ascii or len(set(string)) > 18


def rate_reading(value):
    if value < 50:
        return "below_threshold"
    elif value < 150:
        return "normal"
    elif value < 300:
        return "elevated"
    else:
        return "critical"


# ===================================================================
#  HTML TEMPLATES
# ===================================================================

import base64 as _b64

def _load_asset(name):
    for p in [f"/app/{name}", name, f"assets/{name}"]:
        try:
            with open(p, "rb") as fh:
                return fh.read()
        except FileNotFoundError:
            continue
    return b""

_logo_bytes = _load_asset("logo.jpeg")
_logo_white_bytes = _load_asset("logo-white.png")
_cover_bytes = _load_asset("cover-bg.jpeg")
LOGO_URI = "data:image/jpeg;base64," + _b64.b64encode(_logo_bytes).decode() if _logo_bytes else ""
LOGO_WHITE_URI = "data:image/png;base64," + _b64.b64encode(_logo_white_bytes).decode() if _logo_white_bytes else ""
COVER_URI = "data:image/jpeg;base64," + _b64.b64encode(_cover_bytes).decode() if _cover_bytes else ""

PCMTBE = "PETRONAS Chemicals MTBE Sdn Bhd"

SHARED_CSS = """
* { margin: 0; padding: 0; box-sizing: border-box; }
body { font-family: 'Segoe UI', Tahoma, sans-serif; background: #060d1a; color: #c8d6e5; min-height: 100vh; }
.topbar { background: #0d1b2a; border-bottom: 1px solid #1b2d45; padding: 0.6rem 2rem; display: flex; align-items: center; justify-content: space-between; }
.topbar img { height: 32px; }
.topbar .env { font-size: 0.7rem; color: #4a6fa5; letter-spacing: 1px; text-transform: uppercase; }
nav { background: #0f2439; padding: 0; display: flex; border-bottom: 2px solid #00897b; flex-wrap: wrap; }
nav a { color: #6b8cae; text-decoration: none; padding: 0.7rem 1.4rem; font-size: 0.85rem; font-weight: 500; transition: all 0.2s; border-bottom: 2px solid transparent; }
nav a:hover, nav a.active { color: #00e5b0; border-bottom-color: #00e5b0; background: rgba(0,137,123,0.08); }
.page-title { background: linear-gradient(135deg, #0d2137 0%, #0a192f 100%); padding: 1.8rem 2rem 1.4rem; border-bottom: 1px solid #1b2d45; }
.page-title h1 { color: #00e5b0; font-size: 1.4rem; font-weight: 600; }
.page-title p { color: #4a6fa5; font-size: 0.82rem; margin-top: 0.3rem; }
.container { max-width: 780px; margin: 1.8rem auto; padding: 0 1.5rem; }
.panel { background: #0d1b2a; border: 1px solid #1b2d45; border-radius: 6px; padding: 1.5rem; margin-bottom: 1.2rem; }
.panel h2 { color: #00c9a7; font-size: 1.05rem; margin-bottom: 0.8rem; font-weight: 600; }
.panel p { color: #8899aa; font-size: 0.88rem; line-height: 1.6; }
.form-input { width: 100%; padding: 0.55rem 0.8rem; background: #060d1a; border: 1px solid #1b2d45; color: #c8d6e5; border-radius: 4px; font-size: 0.9rem; outline: none; transition: border 0.2s; }
.form-input:focus { border-color: #00897b; }
.btn { background: linear-gradient(135deg, #00897b, #00695c); color: #fff; border: none; padding: 0.55rem 1.6rem; border-radius: 4px; cursor: pointer; font-size: 0.85rem; font-weight: 500; margin-top: 0.7rem; transition: opacity 0.2s; }
.btn:hover { opacity: 0.85; }
.result-box { margin-top: 1rem; padding: 0.9rem; background: #060d1a; border: 1px solid #1b2d45; border-radius: 4px; }
.result-box.ok { border-color: #1b5e20; }
.result-box.empty { border-color: #1b2d45; color: #4a6fa5; }
.result-item { padding: 0.6rem 0; border-bottom: 1px solid #0d1b2a; }
.result-item:last-child { border-bottom: none; }
.result-item .name { color: #00c9a7; font-weight: 600; font-size: 0.9rem; }
.result-item .meta { color: #6b8cae; font-size: 0.8rem; margin-top: 0.15rem; }
.badge { display: inline-block; padding: 1px 7px; border-radius: 3px; font-size: 0.72rem; font-weight: 500; }
.badge-Online { background: rgba(0,200,120,0.15); color: #00c9a7; }
.badge-Standby { background: rgba(255,152,0,0.15); color: #ffb74d; }
.badge-Maintenance { background: rgba(244,67,54,0.15); color: #e57373; }
.badge-Restricted { background: rgba(156,39,176,0.15); color: #ce93d8; }
.err-msg { color: #e57373; margin-top: 0.8rem; font-size: 0.85rem; }
.footer { text-align: center; color: #2a3f55; padding: 2.5rem 1rem 1.5rem; font-size: 0.75rem; letter-spacing: 0.5px; }
label { display: block; color: #6b8cae; font-size: 0.82rem; margin-bottom: 0.3rem; font-weight: 500; }
"""

NAV_BLOCK = """
<div class="topbar">
    <img src="{{ logo }}" alt="PETRONAS">
    <span class="env">PC MTBE Gebeng &bull; OT Portal</span>
</div>
<nav>
    <a href="/">Home</a>
    <a href="/status">Shipments</a>
    <a href="/directory">Equipment</a>
    <a href="/diagnostics">Diagnostics</a>
    <a href="/safety">HSE</a>
    <a href="/reports">Reports</a>
    <a href="/login">Sign In</a>
</nav>
"""

FOOTER_BLOCK = '<div class="footer">' + PCMTBE + ' (198901003081) &bull; Gebeng Industrial Estate, 26080 Kuantan, Pahang Darul Makmur</div>'

HOME_HTML = """<!DOCTYPE html>
<html lang="en">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Operations Portal | PETRONAS Chemicals MTBE Sdn Bhd</title>
<style>""" + SHARED_CSS + """
.hero { background: linear-gradient(135deg, rgba(6,13,26,0.92), rgba(6,13,26,0.85)), url('{{ cover }}') center/cover; padding: 3rem 2rem 2.4rem; text-align: center; border-bottom: 2px solid #00897b; }
.hero img { height: 52px; margin-bottom: 0.8rem; }
.hero h1 { color: #fff; font-size: 1.5rem; font-weight: 600; }
.hero .sub { color: #4a6fa5; font-size: 0.82rem; margin-top: 0.3rem; }
.grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(210px,1fr)); gap: 1rem; }
.grid .panel:hover { border-color: #00897b; }
.grid .panel h3 { color: #00c9a7; font-size: 0.88rem; margin-bottom: 0.3rem; }
.grid .panel p { font-size: 0.8rem; }
.stat-row { display: flex; gap: 0.8rem; margin-top: 0.6rem; flex-wrap: wrap; }
.stat { flex: 1; min-width: 100px; text-align: center; padding: 0.6rem 0.3rem; background: #060d1a; border-radius: 4px; }
.stat .val { color: #00e5b0; font-size: 1.3rem; font-weight: 700; }
.stat .lbl { color: #4a6fa5; font-size: 0.65rem; text-transform: uppercase; letter-spacing: 0.3px; }
.notice { background: rgba(0,137,123,0.08); border-left: 3px solid #00897b; padding: 0.6rem 0.9rem; font-size: 0.8rem; color: #6b8cae; margin-top: 0.8rem; border-radius: 0 4px 4px 0; }
</style></head>
<body>
""" + NAV_BLOCK + """
<div class="hero">
    <img src="{{ logo_white }}" alt="PETRONAS">
    <h1>MTBE Gebeng Plant Operations Portal</h1>
    <div class="sub">Gebeng Industrial Estate, Kuantan, Pahang &bull; Internal Access Only</div>
</div>
<div class="container">
    <div class="panel">
        <h2>System Overview</h2>
        <p>The Gebeng MTBE plant has been in operation since 1992, using Oleflex Dual Feed technology licensed from UOP. Propane and butane feedstock is supplied via pipeline from the Gas Processing Plant (GPP) in Kerteh, Terengganu. Methanol arrives by sea from Labuan through Kuantan Port.</p>
        <div class="stat-row">
            <div class="stat"><div class="val">19</div><div class="lbl">Registered Assets</div></div>
            <div class="stat"><div class="val">14</div><div class="lbl">Online</div></div>
            <div class="stat"><div class="val">2</div><div class="lbl">Standby</div></div>
            <div class="stat"><div class="val">1</div><div class="lbl">Maintenance</div></div>
        </div>
        <div class="notice">Notice: Scheduled maintenance for GEB-HX02 begins 15 Nov 2026. Contact the Maintenance Department for details.</div>
    </div>
    <div class="grid">
        <div class="panel">
            <h3>Shipment Tracking</h3>
            <p>View incoming raw material orders and outgoing MTBE product dispatch status.</p>
        </div>
        <div class="panel">
            <h3>Equipment Directory</h3>
            <p>Search and view operational status of plant equipment and instrumentation.</p>
        </div>
        <div class="panel">
            <h3>Process Diagnostics</h3>
            <p>Verify reactor readings and run threshold classification checks.</p>
        </div>
        <div class="panel">
            <h3>HSE &amp; Compliance</h3>
            <p>Health, safety, and environmental management procedures and records.</p>
        </div>
    </div>
</div>
""" + FOOTER_BLOCK + """
</body></html>"""

STATUS_HTML = """<!DOCTYPE html>
<html lang="en">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Shipments | PC MTBE Gebeng</title>
<style>""" + SHARED_CSS + """
.info-table { width: 100%; font-size: 0.8rem; margin-top: 1rem; }
.info-table td { padding: 0.3rem 0; color: #6b8cae; }
.info-table td:first-child { color: #4a6fa5; width: 40%; }
</style></head>
<body>
""" + NAV_BLOCK + """
<div class="page-title"><h1>Shipment Status</h1><p>Chemical order fulfilment tracking</p></div>
<div class="container">
    <div class="panel">
        <h2>Order Lookup</h2>
        <p>Your session reference is checked automatically against the order database.</p>
        {{ result_html | safe }}
    </div>
    <div class="panel">
        <h2>Supply Chain Information</h2>
        <table class="info-table">
            <tr><td>Methanol Supplier</td><td>PETRONAS Methanol (Labuan) Sdn Bhd</td></tr>
            <tr><td>Receiving Port</td><td>Kuantan Port Consortium (KPC)</td></tr>
            <tr><td>Primary Feedstock</td><td>Propane, n-Butane (GPP Kerteh pipeline)</td></tr>
            <tr><td>Main Products</td><td>MTBE, Propylene, Hydrogen</td></tr>
            <tr><td>Warehouse Hours</td><td>24h (3 shift rotation)</td></tr>
        </table>
    </div>
</div>
""" + FOOTER_BLOCK + """
</body></html>"""

DIRECTORY_HTML = """<!DOCTYPE html>
<html lang="en">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Equipment Directory | PC MTBE Gebeng</title>
<style>""" + SHARED_CSS + """
</style></head>
<body>
""" + NAV_BLOCK + """
<!-- Directory backend: cn, type, status are public; maintenanceKey is restricted -->
<div class="page-title"><h1>Equipment Directory</h1><p>Plant asset registry and lookup</p></div>
<div class="container">
    <div class="panel">
        <h2>Search</h2>
        <form method="GET" action="/directory">
            <input class="form-input" type="text" name="q" placeholder="Equipment name or identifier ..." value="{{ query }}" autocomplete="off">
            <button class="btn" type="submit">Search</button>
        </form>
        {{ results_html | safe }}
    </div>
</div>
""" + FOOTER_BLOCK + """
</body></html>"""

DIAGNOSTICS_HTML = """<!DOCTYPE html>
<html lang="en">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Process Diagnostics | PC MTBE Gebeng</title>
<style>""" + SHARED_CSS + """
.threshold-table { width: 100%; border-collapse: collapse; margin-top: 0.8rem; font-size: 0.8rem; }
.threshold-table th { text-align: left; color: #4a6fa5; padding: 0.3rem 0.5rem; border-bottom: 1px solid #1b2d45; font-weight: 500; }
.threshold-table td { padding: 0.3rem 0.5rem; color: #6b8cae; }
</style></head>
<body>
""" + NAV_BLOCK + """
<div class="page-title"><h1>Process Diagnostics</h1><p>Oleflex reactor reading verification</p></div>
<div class="container">
    <div class="panel">
        <h2>Reading Classifier</h2>
        <p>Submit a process value for threshold analysis.</p>
        <form method="GET" action="/diagnostics/rate" style="margin-top: 0.8rem;">
            <label for="val">Process Value</label>
            <input class="form-input" type="text" id="val" name="value" placeholder="Enter reading ..." autocomplete="off">
            <button class="btn" type="submit">Check</button>
        </form>
    </div>
    <div class="panel">
        <h2>Operating Thresholds</h2>
        <table class="threshold-table">
            <tr><th>Range</th><th>Classification</th></tr>
            <tr><td>&lt; 50</td><td>Below Threshold</td></tr>
            <tr><td>50 &ndash; 149</td><td>Normal</td></tr>
            <tr><td>150 &ndash; 299</td><td>Elevated</td></tr>
            <tr><td>&ge; 300</td><td>Critical</td></tr>
        </table>
    </div>
</div>
""" + FOOTER_BLOCK + """
</body></html>"""

LOGIN_HTML = """<!DOCTYPE html>
<html lang="en">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Sign In | PC MTBE Gebeng</title>
<style>""" + SHARED_CSS + """
.login-wrap { max-width: 420px; margin: 2rem auto; padding: 0 1.5rem; }
.form-input-pw { width: 100%; padding: 0.55rem 0.8rem; background: #060d1a; border: 1px solid #1b2d45; color: #c8d6e5; border-radius: 4px; font-size: 0.9rem; outline: none; margin-bottom: 0.7rem; }
.error-msg { color: #e57373; margin-top: 0.8rem; padding: 0.6rem 0.8rem; background: rgba(229,115,115,0.08); border: 1px solid rgba(229,115,115,0.2); border-radius: 4px; font-size: 0.85rem; }
</style></head>
<body>
""" + NAV_BLOCK + """
<div class="page-title"><h1>Officer Authentication</h1><p>Authorized personnel only</p></div>
<div class="login-wrap">
    <div class="panel">
        <h2>Sign In</h2>
        <form method="POST" action="/login">
            <label>Username</label>
            <input class="form-input" type="text" name="username" autocomplete="off">
            <label style="margin-top:0.5rem">Password</label>
            <input class="form-input-pw" type="password" name="password">
            <button class="btn" type="submit">Sign In</button>
        </form>
        {{ error_html | safe }}
    </div>
</div>
""" + FOOTER_BLOCK + """
</body></html>"""

ADMIN_HTML = """<!DOCTYPE html>
<html lang="en">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Archive | PC MTBE Gebeng</title>
<style>""" + SHARED_CSS + """
.restricted { border-color: #b71c1c !important; }
.restricted h2 { color: #e57373 !important; }
.key-display { font-family: 'Courier New', monospace; font-size: 1.1rem; color: #ff8a80; background: #0a0008;
        padding: 0.9rem; border-radius: 4px; margin-top: 0.8rem; word-break: break-all; border: 1px solid #4a1020; text-align: center; }
</style></head>
<body>
""" + NAV_BLOCK + """
<div class="page-title" style="border-bottom-color:#b71c1c"><h1 style="color:#e57373">Chemical Process Archive</h1><p>Restricted. Authorized personnel only.</p></div>
<div class="container">
    <div class="panel restricted">
        <h2>Welcome, {{ username }}</h2>
        <p>Process Authorization Key:</p>
        <div class="key-display">{{ flag }}</div>
    </div>
</div>
""" + FOOTER_BLOCK + """
</body></html>"""

SAFETY_HTML = """<!DOCTYPE html>
<html lang="en">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>HSE | PC MTBE Gebeng</title>
<style>""" + SHARED_CSS + """
.section { margin-bottom: 0.8rem; }
.section h3 { color: #00c9a7; font-size: 0.9rem; margin-bottom: 0.3rem; }
.section p, .section li { font-size: 0.82rem; color: #8899aa; line-height: 1.5; }
.section ul { padding-left: 1.2rem; margin-top: 0.3rem; }
.section li { margin-bottom: 0.2rem; }
.stat-bar { display: flex; gap: 0.8rem; margin: 0.8rem 0; flex-wrap: wrap; }
.stat-bar .item { flex: 1; min-width: 120px; background: #060d1a; border-radius: 4px; padding: 0.7rem 0.5rem; text-align: center; }
.stat-bar .item .num { font-size: 1.4rem; font-weight: 700; color: #00e5b0; }
.stat-bar .item .desc { font-size: 0.65rem; color: #4a6fa5; text-transform: uppercase; }
.notice { background: rgba(0,137,123,0.08); border-left: 3px solid #00897b; padding: 0.6rem 0.9rem; font-size: 0.8rem; color: #6b8cae; margin-top: 0.6rem; border-radius: 0 4px 4px 0; }
</style></head>
<body>
""" + NAV_BLOCK + """
<div class="page-title"><h1>Health, Safety &amp; Environment</h1><p>HSE Department, PC MTBE Gebeng</p></div>
<div class="container">
    <div class="panel">
        <h2>HSE Performance 2026</h2>
        <div class="stat-bar">
            <div class="item"><div class="num">1,247</div><div class="desc">Days Without Incident</div></div>
            <div class="item"><div class="num">98.6%</div><div class="desc">Audit Compliance</div></div>
            <div class="item"><div class="num">0</div><div class="desc">Chemical Spills</div></div>
            <div class="item"><div class="num">412</div><div class="desc">HSE Trainings Done</div></div>
        </div>
        <div class="notice">MSOSH Award 2025: PC MTBE received the Gold Award for occupational health and safety performance.</div>
    </div>
    <div class="panel">
        <div class="section">
            <h3>Emergency Procedures</h3>
            <p>All personnel must follow the plant emergency response procedures. Fire and gas leak drills are scheduled every quarter.</p>
            <ul>
                <li>Assembly points: North parking lot (Zone A), Administration building (Zone B)</li>
                <li>Internal emergency hotline: 8888</li>
                <li>Gebeng Fire Department: 09-583 7994</li>
            </ul>
        </div>
    </div>
    <div class="panel">
        <div class="section">
            <h3>Chemical Handling</h3>
            <p>All chemicals handled at this plant are subject to the Occupational Safety and Health Act 1994 (Act 514) and CLASS Regulations 2013. Safety Data Sheets (SDS) for each substance are available in the control room.</p>
        </div>
        <div class="section">
            <h3>Environmental Management</h3>
            <p>PC MTBE complies with emission standards set by the Department of Environment (DOE). The wastewater treatment system operates 24 hours with continuous pH, BOD, and TSS monitoring.</p>
        </div>
    </div>
    <div class="panel">
        <div class="section">
            <h3>Personal Protective Equipment (PPE)</h3>
            <ul>
                <li>Plant area: Safety helmet, safety boots, safety glasses</li>
                <li>Reactor area: Chemical resistant suit, nitrile gloves, SCBA breathing apparatus</li>
                <li>Jetty area: Life jacket, antistatic footwear</li>
            </ul>
        </div>
    </div>
</div>
""" + FOOTER_BLOCK + """
</body></html>"""

REPORTS_HTML = """<!DOCTYPE html>
<html lang="en">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Reports | PC MTBE Gebeng</title>
<style>""" + SHARED_CSS + """
.report-table { width: 100%; border-collapse: collapse; font-size: 0.82rem; margin-top: 0.6rem; }
.report-table th { text-align: left; color: #4a6fa5; padding: 0.4rem 0.5rem; border-bottom: 1px solid #1b2d45; font-weight: 500; font-size: 0.72rem; text-transform: uppercase; }
.report-table td { padding: 0.4rem 0.5rem; border-bottom: 1px solid #0d1926; color: #8fa4be; }
.report-table tr:hover td { background: rgba(0,137,123,0.05); }
.tag { display: inline-block; padding: 1px 6px; border-radius: 3px; font-size: 0.7rem; font-weight: 500; }
.tag-ok { background: rgba(0,200,120,0.15); color: #00c9a7; }
.tag-pending { background: rgba(255,152,0,0.15); color: #ffb74d; }
.chart-placeholder { background: #060d1a; border: 1px solid #1b2d45; border-radius: 4px; padding: 1.2rem; text-align: center; color: #4a6fa5; font-size: 0.78rem; margin-top: 0.6rem; }
</style></head>
<body>
""" + NAV_BLOCK + """
<div class="page-title"><h1>Production Reports</h1><p>Monthly operations summary for PC MTBE Gebeng</p></div>
<div class="container">
    <div class="panel">
        <h2>October 2026 Output</h2>
        <table class="report-table">
            <tr><th>Product</th><th>Target (MT)</th><th>Actual (MT)</th><th>Achievement</th><th>Status</th></tr>
            <tr><td>MTBE</td><td>24,500</td><td>24,180</td><td>98.7%</td><td><span class="tag tag-ok">Met</span></td></tr>
            <tr><td>Propylene</td><td>18,200</td><td>17,850</td><td>98.1%</td><td><span class="tag tag-ok">Met</span></td></tr>
            <tr><td>Hydrogen</td><td>3,100</td><td>2,940</td><td>94.8%</td><td><span class="tag tag-ok">Met</span></td></tr>
        </table>
    </div>
    <div class="panel">
        <h2>Feedstock Consumption</h2>
        <table class="report-table">
            <tr><th>Material</th><th>Source</th><th>Quantity (MT)</th><th>Status</th></tr>
            <tr><td>Propane</td><td>GPP Kerteh (Pipeline)</td><td>31,200</td><td><span class="tag tag-ok">Normal</span></td></tr>
            <tr><td>n-Butane</td><td>GPP Kerteh (Pipeline)</td><td>12,400</td><td><span class="tag tag-ok">Normal</span></td></tr>
            <tr><td>Methanol</td><td>Labuan (Sea)</td><td>8,600</td><td><span class="tag tag-pending">Delayed</span></td></tr>
        </table>
        <div class="chart-placeholder">Production graphs are not available in portal mode. Use the PI System for real-time data.</div>
    </div>
    <div class="panel">
        <h2>Equipment Availability</h2>
        <table class="report-table">
            <tr><th>Unit</th><th>Availability</th><th>Operating Hours</th><th>Notes</th></tr>
            <tr><td>Oleflex Reactor Train A</td><td>99.2%</td><td>713 hrs</td><td>No issues</td></tr>
            <tr><td>Oleflex Reactor Train B</td><td>97.8%</td><td>704 hrs</td><td>Catalyst inspection</td></tr>
            <tr><td>MTBE Synthesis Unit</td><td>98.5%</td><td>709 hrs</td><td>No issues</td></tr>
            <tr><td>PDH Furnace</td><td>96.1%</td><td>692 hrs</td><td>Tube replacement</td></tr>
            <tr><td>Distillation Column C-101</td><td>99.8%</td><td>718 hrs</td><td>No issues</td></tr>
        </table>
    </div>
    <div class="panel">
        <h2>Dispatch Records</h2>
        <table class="report-table">
            <tr><th>Date</th><th>Customer</th><th>Product</th><th>Qty (MT)</th><th>Destination</th></tr>
            <tr><td>28 Oct</td><td>Shell Eastern Petroleum</td><td>MTBE</td><td>4,200</td><td>Singapore</td></tr>
            <tr><td>25 Oct</td><td>Thai Oil PCL</td><td>MTBE</td><td>3,800</td><td>Laem Chabang</td></tr>
            <tr><td>22 Oct</td><td>Hengyuan Refining</td><td>MTBE</td><td>2,100</td><td>Port Klang</td></tr>
            <tr><td>19 Oct</td><td>Lotte Chemical Titan</td><td>Propylene</td><td>5,500</td><td>Pasir Gudang</td></tr>
            <tr><td>15 Oct</td><td>IRPC PCL</td><td>MTBE</td><td>3,200</td><td>Rayong</td></tr>
        </table>
    </div>
</div>
""" + FOOTER_BLOCK + """
</body></html>"""


# ===================================================================
#  ROUTES
# ===================================================================

@app.before_request
def parse_raw_order_cookie():
    raw = request.environ.get("HTTP_COOKIE", "")
    request._raw_order_ref = ""
    if raw:
        for part in raw.split(";"):
            part = part.strip()
            if part.startswith("OrderRef="):
                val = part[len("OrderRef="):]
                request._raw_order_ref = val.strip('"')
                break


@app.after_request
def set_order_cookie(response):
    if "OrderRef" not in request.cookies and not request._raw_order_ref:
        if response.status_code == 200:
            response.set_cookie("OrderRef", uuid.uuid4().hex[:16])
    return response


@app.route("/")
def home():
    return render_template_string(HOME_HTML, logo=LOGO_URI, logo_white=LOGO_WHITE_URI, cover=COVER_URI)


@app.route("/status")
def order_status():
    order_ref = getattr(request, "_raw_order_ref", "") or request.cookies.get("OrderRef", "")
    result_html = ""

    if not order_ref:
        result_html = '<div class="result-box empty">No reference found for this session.</div>'
    elif order_ref:
        try:
            conn = sqlite3.connect(DB_PATH)
            c = conn.cursor()
            query = f"SELECT chemical, quantity, status FROM order_tracking WHERE order_ref = '{order_ref}'"
            c.execute(query)
            row = c.fetchone()
            conn.close()

            if row:
                result_html = f'''
                <div class="result-box ok">
                    <strong>{row[0]}</strong> &bull; {row[1]}<br>
                    <span style="color:#6b8cae">Status: {row[2]}</span>
                </div>'''
            else:
                result_html = '<div class="result-box empty">No records found for this reference.</div>'
        except Exception:
            result_html = '<div class="result-box empty">No records found for this reference.</div>'

    return render_template_string(STATUS_HTML, result_html=result_html, logo=LOGO_URI)


@app.route("/login", methods=["GET", "POST"])
def login():
    error_html = ""
    if request.method == "POST":
        username = request.form.get("username", "")
        password = request.form.get("password", "")
        try:
            conn = sqlite3.connect(DB_PATH)
            c = conn.cursor()
            c.execute("SELECT role FROM users WHERE username=? AND password=?",
                      (username, password))
            row = c.fetchone()
            conn.close()
            if row and row[0] == "admin":
                resp = make_response(render_template_string(ADMIN_HTML,
                    username=username, flag=FLAG_SQLI, logo=LOGO_URI))
                return resp
            elif row:
                error_html = '<div class="error-msg">Access denied. Your account does not have admin privileges.</div>'
            else:
                error_html = '<div class="error-msg">Invalid username or password.</div>'
        except Exception:
            error_html = '<div class="error-msg">System error. Try again.</div>'
    return render_template_string(LOGIN_HTML, error_html=error_html, logo=LOGO_URI)


@app.route("/directory")
def directory():
    query = request.args.get("q", "")
    results_html = ""

    if query:
        try:
            results = ldap_search(query)
            if results:
                items = ""
                for r in results:
                    status_class = r["status"].replace(" ", "")
                    restricted_note = ''
                    if r["status"] == "Restricted":
                        restricted_note = '<div style="color:#6b4a8c;font-size:0.72rem;margin-top:2px">Access locked — requires valid <b>maintenanceKey</b></div>'
                    items += f'''
                    <div class="result-item">
                        <div class="name">{r["cn"]}</div>
                        <div class="meta">{r["type"]} &bull;
                        <span class="badge badge-{status_class}">{r["status"]}</span></div>
                        {restricted_note}
                    </div>'''
                results_html = f'<div class="result-box">{items}</div>'
            else:
                results_html = '<div class="result-box empty">No records found.</div>'
        except LDAPFilterError:
            results_html = '<div class="err-msg">lookup error: LDAPInvalidFilterError</div>'
        except LDAPAttributeError as e:
            results_html = f'<div class="err-msg">lookup error: LDAPAttributeError: {e}</div>'

    return render_template_string(DIRECTORY_HTML, query=query, results_html=results_html, logo=LOGO_URI)


@app.route("/diagnostics")
def diagnostics():
    return render_template_string(DIAGNOSTICS_HTML, logo=LOGO_URI)


@app.route("/diagnostics/rate")
def diagnostics_rate():
    value = request.args.get("value", "")
    if not value:
        return jsonify(error="no value provided"), 400
    if check_diagnostic_input(value):
        return "Invalid reading!", 400
    result = eval(value.lower())
    return jsonify(verdict=rate_reading(result), value=float(result))


@app.route("/safety")
def safety():
    return render_template_string(SAFETY_HTML, logo=LOGO_URI)

@app.route("/reports")
def reports():
    return render_template_string(REPORTS_HTML, logo=LOGO_URI)


if __name__ == "__main__":
    from werkzeug.debug import DebuggedApplication
    app.config["PROPAGATE_EXCEPTIONS"] = True
    app.wsgi_app = DebuggedApplication(app.wsgi_app, evalex=False)
    app.run("0.0.0.0", port=5000, debug=False)
